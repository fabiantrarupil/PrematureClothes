import { createContext, useState, useEffect } from "react";

export const ProductContext = createContext();

const ProductProvider = ({ children }) => {
    const [productos, setProductos] = useState([]);

    // 1. Inicializamos 'user' (Copia este bloque completo)
    const [user, setUser] = useState(() => {

        // OPCIÓN A: Administrador (Acceso total)
        /*
        return { 
            id: 1, 
            nombre: "Admin Premature", 
            email: "admin@test.com", 
            role: "admin" 
        };
        */

        // OPCIÓN B: Vendedor (Solo estadísticas y ventas)
        /*
        return { 
            id: 2, 
            nombre: "Vendedor Ropa", 
            email: "vendedor@test.com", 
            role: "vendedor" 
        };
        */
        // OPCIÓN C: Cliente / Usuario Normal (Solo compras)
        
        return { 
            id: 3, 
            nombre: "Juan Perez", 
            email: "juan@test.com", 
            role: "user" 
        };
        

        // LÓGICA REAL: (Descomenta esto cuando quieras que funcione el Login real)
        const savedUser = localStorage.getItem("user");
        return savedUser ? JSON.parse(savedUser) : null;
    });

    // 2. Inicializamos 'carrito' desde LocalStorage
    const [carrito, setCarrito] = useState(() => {
        const savedCart = localStorage.getItem("carrito");
        return savedCart ? JSON.parse(savedCart) : [];
    });

    // 3. Inicializamos 'favoritos' desde LocalStorage (Solo una vez)
    const [favoritos, setFavoritos] = useState(() => {
        const savedFavs = localStorage.getItem("favoritos");
        return savedFavs ? JSON.parse(savedFavs) : [];
    });

    // --- EFECTOS DE PERSISTENCIA ---
    useEffect(() => {
        if (user) {
            localStorage.setItem("user", JSON.stringify(user));
        } else {
            localStorage.removeItem("user");
        }
    }, [user]);

    useEffect(() => {
        localStorage.setItem("carrito", JSON.stringify(carrito));
    }, [carrito]);

    useEffect(() => {
        localStorage.setItem("favoritos", JSON.stringify(favoritos));
    }, [favoritos]);

    // --- FUNCIONES ---
    const logout = () => {
        setUser(null);
        localStorage.removeItem("user");
        localStorage.removeItem("carrito");
    };

    const toggleFavorito = (producto) => {
        setFavoritos(prev => {
            const existe = prev.find(p => p.id === producto.id);
            if (existe) return prev.filter(p => p.id !== producto.id);
            return [...prev, producto];
        });
    };

    const agregarAlCarrito = (producto) => {
        setCarrito((prev) => {
            const existe = prev.find((item) => item.id === producto.id);
            if (existe) {
                return prev.map((item) =>
                    item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item
                );
            }
            return [...prev, { ...producto, cantidad: 1 }];
        });
    };

    const eliminarDelCarrito = (id) => {
        setCarrito((prev) => prev.filter((item) => item.id !== id));
    };

    const ajustarCantidad = (id, delta) => {
        setCarrito((prev) =>
            prev.map((item) =>
                item.id === id ? { ...item, cantidad: Math.max(1, item.cantidad + delta) } : item
            )
        );
    };

    const totalCarrito = carrito.reduce((acc, item) => acc + item.precio * item.cantidad, 0);
    const cantidadTotalItems = carrito.reduce((acc, item) => acc + item.cantidad, 0);

    // Carga inicial de productos
    useEffect(() => {
        const productosBase = [
            {
                id: 1,
                nombre: "Body Algodón Pima 'Primer Abrazo'",
                precio: 14990,
                img: "https://baberin.cl/cdn/shop/files/I6B1736_2_6b1a7970-977d-4814-81ad-b0978ac78d08.jpg?v=1717876817&width=640",
                desc: "Apertura frontal completa para evitar manipular cables de monitoreo. Algodón 100% hipoalergénico."
            },
            {
                id: 2,
                nombre: "Gorrito Termorregulador UCIN",
                precio: 6500,
                img: "https://www.pumucki.cl/pumucki2022/wp-content/uploads/2022/07/goe-20-tib-celeste-dos.jpg",
                desc: "Mantiene el calor corporal esencial en las primeras semanas. Sin costuras internas irritantes."
            },
            {
                id: 3,
                nombre: "Set de Calcetines 'Pasitos de Fe'",
                precio: 8990,
                img: "https://http2.mlstatic.com/D_NQ_NP_2X_812909-MLC46418820085_062021-F-set-calcetines-semanales-para-bebe-7-pares.webp",
                desc: "Tejido ultra suave con ajuste elástico ligero que no marca la piel delicada."
            },
            {
                id: 4,
                nombre: "Tutos de Algodón Orgánico'",
                precio: 24990,
                img: "https://cdnx.jumpseller.com/prueba-bebe/image/59957869/thumb/760/760?1738956095",
                desc: "Mantiene las piernas en posición de 'ranita' recomendada por fisioterapeutas."
            },
            {
                id: 5,
                nombre: "Manta de Apego 'Antümalen'",
                precio: 12500,
                img: "https://cdnx.jumpseller.com/prueba-bebe/image/58518747/thumb/760/760?1734716773",
                desc: "Textura suave para estimulación sensorial temprana. Segura para incubadora."
            },
            {
                id: 6,
                nombre: "Pijama Enterito con Pies",
                precio: 18990,
                img: "https://hmchile.vtexassets.com/unsafe/1280x0/center/middle/https%3A%2F%2Fhmchile.vtexassets.com%2Farquivos%2Fids%2F7642427%2FPack-de-2-pijamas-enteritos-en-algodon---Verde-claro-Animales---H-M-CL.jpg%3Fv%3D638926480193330000",
                desc: "Broches de presión plásticos (libres de níquel) para facilitar exámenes médicos."
            },
            {
                id: 7,
                nombre: "Cojín de Posicionamiento",
                precio: 15990,
                img: "https://www.madremia.cl/cdn/shop/products/Mimos_caja_ppl_cojin_para_bebe.jpg?v=1601494210",
                desc: "Ayuda a mantener la postura correcta y evitar la plagiocefalia postural."
            },
            {
                id: 8,
                nombre: "Bandana Babita de Bambú",
                precio: 5500,
                img: "https://images.unsplash.com/photo-1622290319146-7b63df48a635?q=80&w=800",
                desc: "Súper absorbente y antibacteriana. Ideal para pieles con dermatitis atópica."
            },
            {
                id: 9,
                nombre: "Kit Bienvenida Prematuro",
                precio: 35000,
                img: "https://http2.mlstatic.com/D_NQ_NP_670577-MLU54971661863_042023-O.webp",
                desc: "Incluye body, gorro, calcetines y guía de cuidados iniciales para padres."
            }
        ];
        setProductos(productosBase);
    }, []);

    return (
        <ProductContext.Provider
            value={{
                productos,
                setProductos,
                user,
                setUser,
                logout,
                carrito,
                setCarrito,
                agregarAlCarrito,
                eliminarDelCarrito,
                ajustarCantidad,
                totalCarrito,
                cantidadTotalItems, // Se corrigió la coma aquí
                favoritos,
                toggleFavorito
            }}
        >
            {children}
        </ProductContext.Provider>
    );
};

export default ProductProvider;