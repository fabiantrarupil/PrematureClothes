import { useContext } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { Heart, ShoppingCart, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Favoritos = () => {
  const { favoritos, toggleFavorito, agregarAlCarrito } = useContext(ProductContext);
  const navigate = useNavigate();

  return (
    <Container className="my-5 pt-4">
      <h2 className="fw-bold mb-4">Mis Favoritos ❤️</h2>
      
      {favoritos.length === 0 ? (
        <Card className="text-center p-5 border-0 shadow-sm rounded-4">
          <p className="text-muted fs-5">Aún no tienes productos guardados.</p>
          <Button 
            variant="primary" 
            className="w-auto mx-auto border-0" 
            style={{ backgroundColor: '#ff85a2' }}
            onClick={() => navigate('/catalogo')}
          >
            Explorar Catálogo
          </Button>
        </Card>
      ) : (
        <Row className="g-4">
          {favoritos.map((prod) => (
            <Col key={prod.id} xs={12} md={6} lg={4}>
              <Card className="h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                <Card.Img 
                  variant="top" 
                  src={prod.img} 
                  style={{ height: '200px', objectFit: 'contain', padding: '15px' }} 
                />
                <Card.Body>
                  <Card.Title className="fw-bold text-truncate">{prod.nombre}</Card.Title>
                  <h5 className="fw-bold" style={{ color: '#ff85a2' }}>
                    ${prod.precio.toLocaleString('es-CL')}
                  </h5>
                  <div className="d-flex gap-2 mt-3">
                    <Button 
                      variant="primary" 
                      className="flex-grow-1 border-0" 
                      style={{ backgroundColor: '#ff85a2' }}
                      onClick={() => agregarAlCarrito(prod)}
                    >
                      <ShoppingCart size={18} className="me-2" /> Carrito
                    </Button>
                    <Button 
                      variant="outline-danger" 
                      onClick={() => toggleFavorito(prod)}
                    >
                      <Trash2 size={18} />
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </Container>
  );
};

export default Favoritos;