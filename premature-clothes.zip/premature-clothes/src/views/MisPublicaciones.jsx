import { useContext } from 'react';
import { Container, Table, Button, Badge, Card } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { Edit3, Trash2, Plus, ExternalLink, PackageOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const MisPublicaciones = () => {
  const { productos, user } = useContext(ProductContext);
  const navigate = useNavigate();

  // Para probar el estado vacío, puedes cambiar esto a productos.slice(0, 0)
  const misProductos = productos.slice(0, 3); 

  return (
    <Container className="my-5 pt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold m-0">Mis Publicaciones</h2>
          <p className="text-muted">Gestiona la ropa que tienes a la venta para otros guerreros.</p>
        </div>
        <Button 
          variant="primary" 
          style={{ backgroundColor: '#ff85a2', border: 'none' }}
          onClick={() => navigate('/publicar')}
          className="fw-bold shadow-sm"
        >
          <Plus size={18} className="me-2" /> Nueva Publicación
        </Button>
      </div>

      <Card className="border-0 shadow-sm rounded-4 overflow-hidden">
        <Table responsive hover className="align-middle mb-0">
          <thead className="bg-light">
            <tr>
              <th className="px-4 py-3">Producto</th>
              <th className="py-3">Precio</th>
              <th className="py-3">Estado</th>
              <th className="py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {misProductos.length > 0 ? (
              misProductos.map((item) => (
                <tr key={item.id}>
                  <td className="px-4 py-3">
                    <div className="d-flex align-items-center">
                      <img 
                        src={item.img} 
                        alt={item.nombre} 
                        style={{ width: '50px', height: '50px', objectFit: 'contain' }} 
                        className="me-3 rounded bg-light" 
                      />
                      <span className="fw-bold">{item.nombre}</span>
                    </div>
                  </td>
                  <td>${item.precio.toLocaleString('es-CL')}</td>
                  <td>
                    <Badge bg="success" className="fw-normal">Activo</Badge>
                  </td>
                  <td className="text-center">
                    <div className="d-flex justify-content-center gap-2">
                      <Button variant="outline-secondary" size="sm" title="Editar">
                        <Edit3 size={16} />
                      </Button>
                      <Button variant="outline-danger" size="sm" title="Eliminar">
                        <Trash2 size={16} />
                      </Button>
                      <Button 
                        variant="light" 
                        size="sm" 
                        onClick={() => navigate(`/producto/${item.id}`)} 
                        title="Ver en tienda"
                      >
                        <ExternalLink size={16} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              // VISTA PARA ESTADO VACÍO
              <tr>
                <td colSpan="4" className="text-center py-5">
                  <div className="d-flex flex-column align-items-center opacity-75">
                    <PackageOpen size={48} className="text-muted mb-3" />
                    <h5 className="fw-bold text-muted">Aún no tienes productos publicados</h5>
                    <p className="text-muted mb-4">¡Dale una segunda vida a la ropita de tu guerrero!</p>
                    <Button 
                      variant="outline-primary" 
                      onClick={() => navigate('/publicar')}
                      style={{ color: '#ff85a2', borderColor: '#ff85a2' }}
                      className="rounded-pill px-4"
                    >
                      Empezar a vender
                    </Button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </Card>
    </Container>
  );
};

export default MisPublicaciones;