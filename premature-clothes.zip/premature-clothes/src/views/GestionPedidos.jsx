import { Container, Table, Badge, Button, Card } from 'react-bootstrap';
import { Eye, Truck, CheckCircle, Clock } from 'lucide-react';

const GestionPedidos = () => {
  // Simulamos datos de pedidos recibidos
  const pedidos = [
    { id: '#1001', fecha: '2026-02-01', cliente: 'María López', total: 25990, estado: 'Pendiente', color: 'warning' },
    { id: '#1002', fecha: '2026-02-02', cliente: 'Juan Pérez', total: 15500, estado: 'Enviado', color: 'info' },
    { id: '#1003', fecha: '2026-02-04', cliente: 'Ana Soto', total: 42000, estado: 'Entregado', color: 'success' },
  ];

  return (
    <Container className="my-5 pt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold m-0">Gestión de Pedidos 📦</h2>
          <p className="text-muted">Controla las ventas y estados de envío de tus productos.</p>
        </div>
      </div>

      <Card className="border-0 shadow-sm rounded-4 overflow-hidden">
        <Table responsive hover className="align-middle mb-0">
          <thead className="bg-light">
            <tr>
              <th className="px-4 py-3">ID Pedido</th>
              <th className="py-3">Fecha</th>
              <th className="py-3">Cliente</th>
              <th className="py-3">Total</th>
              <th className="py-3">Estado</th>
              <th className="py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {pedidos.map((pedido) => (
              <tr key={pedido.id}>
                <td className="px-4 py-3 fw-bold text-primary">{pedido.id}</td>
                <td>{pedido.fecha}</td>
                <td>{pedido.cliente}</td>
                <td className="fw-bold">${pedido.total.toLocaleString('es-CL')}</td>
                <td>
                  <Badge bg={pedido.color} className="fw-normal px-3 py-2">
                    {pedido.estado === 'Pendiente' && <Clock size={14} className="me-1" />}
                    {pedido.estado === 'Enviado' && <Truck size={14} className="me-1" />}
                    {pedido.estado === 'Entregado' && <CheckCircle size={14} className="me-1" />}
                    {pedido.estado}
                  </Badge>
                </td>
                <td className="text-center">
                  <div className="d-flex justify-content-center gap-2">
                    <Button variant="outline-secondary" size="sm" title="Ver detalle">
                      <Eye size={16} />
                    </Button>
                    <Button 
                      variant="primary" 
                      size="sm" 
                      style={{ backgroundColor: '#ff85a2', border: 'none' }}
                      title="Actualizar estado"
                    >
                      Actualizar
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </Container>
  );
};

export default GestionPedidos;