import { useContext } from 'react';
import { Container, Row, Col, Card, Button, ListGroup } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
// 👇 Asegúrate de importar 'Settings' y 'useNavigate'
import { User, Mail, Package, Heart, LogOut, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const { user, logout, favoritos, carrito } = useContext(ProductContext);
  const navigate = useNavigate(); // <-- Añadimos el hook de navegación

  if (!user) {
    return (
      <Container className="mt-5 text-center">
        <h3 className="mb-4">Debes iniciar sesión para ver tu perfil</h3>
      </Container>
    );
  }

  return (
    <Container className="my-5 pt-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="border-0 shadow-sm rounded-4 overflow-hidden">
            {/* Header del Perfil */}
            <div className="p-4 text-white text-center position-relative" style={{ backgroundColor: '#ff85a2' }}>
              
              {/* 👇 BOTÓN EDITAR PERFIL (Esquina superior derecha) */}
              <Button 
                variant="light" 
                size="sm" 
                className="position-absolute top-0 end-0 m-3 rounded-circle shadow-sm border-0"
                style={{ width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                onClick={() => navigate('/editar-perfil')}
                title="Editar mi perfil"
              >
                <Settings size={20} color="#ff85a2" />
              </Button>

              <div className="bg-white rounded-circle d-inline-block p-3 mb-3 shadow-sm">
                <User size={50} color="#ff85a2" />
              </div>
              <h2 className="fw-bold mb-0">{user.nombre || 'Usuario'}</h2>
              <p className="opacity-75">{user.email}</p>
            </div>
            
            <Card.Body className="p-4">
              <h5 className="fw-bold mb-4">Mi Actividad</h5>
              <ListGroup variant="flush">
                <ListGroup.Item className="d-flex align-items-center py-3 border-0">
                  <Package className="me-3 text-muted" size={20} />
                  <span>Mis Compras ({carrito?.length || 0})</span>
                  <Button variant="link" className="ms-auto p-0 text-decoration-none" style={{ color: '#ff85a2' }}>Ver historial</Button>
                </ListGroup.Item>
                <ListGroup.Item className="d-flex align-items-center py-3 border-0">
                  <Heart className="me-3 text-muted" size={20} />
                  <span>Mis Favoritos ({favoritos?.length || 0})</span>
                  <Button 
                    variant="link" 
                    className="ms-auto p-0 text-decoration-none" 
                    style={{ color: '#ff85a2' }}
                    onClick={() => navigate('/favoritos')} // <-- Conectamos también este botón
                  >
                    Ver lista
                  </Button>
                </ListGroup.Item>
              </ListGroup>

              <div className="mt-5 border-top pt-4 text-center">
                <Button variant="outline-danger" className="border-0 fw-bold" onClick={logout}>
                  <LogOut size={18} className="me-2" /> Cerrar Sesión
                </Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Profile;