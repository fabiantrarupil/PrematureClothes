import { useState, useContext } from 'react';
import { Container, Card, Form, Button, Row, Col, Alert } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { User, Mail, Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const EditarPerfil = () => {
  const { user, setUser } = useContext(ProductContext);
  const navigate = useNavigate();

  // Estado local para el formulario
  const [formData, setFormData] = useState({
    nombre: user?.nombre || '',
    email: user?.email || '',
    direccion: user?.direccion || 'Pedro León Gallo 678, Providencia' // Valor por defecto basado en tu info
  });

  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Actualizamos el contexto (el useEffect del Context se encargará del localStorage)
    setUser({ ...user, ...formData });
    setShowSuccess(true);

    // Feedback positivo y redirección suave
    setTimeout(() => {
      setShowSuccess(false);
      navigate('/profile');
    }, 2000);
  };

  return (
    <Container className="my-5 pt-4">
      <Row className="justify-content-center">
        <Col md={6}>
          <Button
            variant="link"
            className="text-decoration-none mb-3 p-0"
            style={{ color: '#ff85a2' }}
            onClick={() => navigate('/perfil')}
          >
            <ArrowLeft size={18} className="me-1" /> Volver al perfil
          </Button>

          <Card className="border-0 shadow-sm rounded-4 p-4">
            <h2 className="fw-bold mb-4">Editar Perfil</h2>

            {showSuccess && (
              <Alert variant="success" className="border-0 rounded-3">
                ¡Perfil actualizado con éxito! ✨
              </Alert>
            )}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label className="fw-bold"><User size={16} className="me-1" /> Nombre Completo</Form.Label>
                <Form.Control
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                  placeholder="Tu nombre"
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="fw-bold"><Mail size={16} className="me-1" /> Correo Electrónico</Form.Label>
                <Form.Control
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </Form.Group>

              <div className="d-grid mt-4">
                <Button
                  type="submit"
                  variant="primary"
                  className="fw-bold py-2 border-0 shadow-sm"
                  style={{ backgroundColor: '#ff85a2' }}
                >
                  <Save size={18} className="me-2" /> Guardar Cambios
                </Button>
              </div>
            </Form>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default EditarPerfil;