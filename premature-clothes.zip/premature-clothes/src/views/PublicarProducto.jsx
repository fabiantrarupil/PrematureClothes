import { useState, useContext } from 'react';
import { Container, Row, Col, Card, Form, Button } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { useNavigate } from 'react-router-dom';
import { Camera, Tag, DollarSign, FileText, Send } from 'lucide-react';

const PublicarProducto = () => {
  const { setProductos } = useContext(ProductContext);
  const navigate = useNavigate();

  const [nuevoProducto, setNuevoProducto] = useState({
    nombre: '',
    precio: '',
    img: '',
    desc: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulamos la creación añadiéndolo al estado global
    const id = Date.now(); // Generamos un ID simple
    const productoParaSubir = { ...nuevoProducto, id, precio: Number(nuevoProducto.precio) };
    
    setProductos(prev => [productoParaSubir, ...prev]);
    alert("¡Producto publicado con éxito!");
    navigate('/mis-publicaciones');
  };

  const handleChange = (e) => {
    setNuevoProducto({ ...nuevoProducto, [e.target.name]: e.target.value });
  };

  return (
    <Container className="my-5 pt-4">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <Card className="border-0 shadow-lg rounded-4 p-4">
            <h2 className="fw-bold mb-4 text-center">Nueva Publicación</h2>
            <Form onSubmit={handleSubmit}>
              
              <Form.Group className="mb-3">
                <Form.Label className="small fw-bold"><Tag size={16} className="me-2"/>Nombre del Producto</Form.Label>
                <Form.Control 
                  name="nombre" 
                  placeholder="Ej: Body prematuro algodón" 
                  onChange={handleChange} 
                  required 
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="small fw-bold"><DollarSign size={16} className="me-2"/>Precio</Form.Label>
                <Form.Control 
                  type="number" 
                  name="precio" 
                  placeholder="Precio en CLP" 
                  onChange={handleChange} 
                  required 
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="small fw-bold"><Camera size={16} className="me-2"/>URL de la Imagen</Form.Label>
                <Form.Control 
                  name="img" 
                  placeholder="https://link-de-la-foto.jpg" 
                  onChange={handleChange} 
                  required 
                />
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="small fw-bold"><FileText size={16} className="me-2"/>Descripción</Form.Label>
                <Form.Control 
                  as="textarea" 
                  rows={3} 
                  name="desc" 
                  placeholder="Describe el estado y la talla (000, 00, etc.)" 
                  onChange={handleChange} 
                  required 
                />
              </Form.Group>

              <Button 
                variant="primary" 
                type="submit" 
                className="w-100 py-3 fw-bold border-0 shadow"
                style={{ backgroundColor: '#ff85a2' }}
              >
                <Send size={18} className="me-2" /> Publicar ahora
              </Button>
            </Form>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default PublicarProducto;