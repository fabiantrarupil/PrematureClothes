import { useContext } from 'react';
import { Container, Table, Button, Row, Col, Card } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CarritoCompras = () => {
  const { carrito, totalCarrito, eliminarDelCarrito, ajustarCantidad } = useContext(ProductContext);
  const navigate = useNavigate();

  if (carrito.length === 0) {
    return (
      <Container className="text-center py-5 mt-5">
        <ShoppingBag size={80} className="text-muted mb-4 opacity-50" />
        <h2 className="fw-bold">Tu carrito está vacío</h2>
        <p className="text-muted mb-4">Parece que aún no has añadido nada para tu bebé.</p>
        <Button 
          variant="primary" 
          className="border-0 px-4 py-2 fw-bold" 
          style={{ backgroundColor: '#ff85a2' }}
          onClick={() => navigate('/catalogo')}
        >
          Ir al catálogo
        </Button>
      </Container>
    );
  }

  return (
    <Container className="my-5 pt-4">
      <div className="d-flex align-items-center mb-4">
        <Button variant="link" onClick={() => navigate(-1)} className="text-muted p-0 me-3">
          <ArrowLeft size={20} />
        </Button>
        <h2 className="fw-bold m-0">Mi Carrito</h2>
      </div>

      <Row className="gy-4">
        {/* Lista de Productos */}
        <Col lg={8}>
          <div className="bg-white rounded-4 shadow-sm border overflow-hidden">
            <Table responsive className="align-middle mb-0">
              <thead className="bg-light">
                <tr>
                  <th className="px-4 py-3 border-0">Producto</th>
                  <th className="py-3 border-0">Precio</th>
                  <th className="py-3 border-0">Cantidad</th>
                  <th className="py-3 border-0 text-end px-4">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {carrito.map(item => (
                  <tr key={item.id} className="border-bottom">
                    <td className="px-4 py-3">
                      <div className="d-flex align-items-center">
                        <img 
                          src={item.img} 
                          alt={item.nombre} 
                          style={{ width: '60px', height: '60px', objectFit: 'contain' }} 
                          className="me-3 rounded border bg-light" 
                        />
                        <div>
                          <div className="fw-bold mb-1">{item.nombre}</div>
                          <Button 
                            variant="link" 
                            className="text-danger p-0 small text-decoration-none" 
                            style={{ fontSize: '0.8rem' }}
                            onClick={() => eliminarDelCarrito(item.id)}
                          >
                            <Trash2 size={14} className="me-1" /> Quitar
                          </Button>
                        </div>
                      </div>
                    </td>
                    <td className="text-muted">${item.precio.toLocaleString('es-CL')}</td>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <Button 
                          variant="light" 
                          size="sm" 
                          className="border"
                          onClick={() => ajustarCantidad(item.id, -1)}
                        >
                          <Minus size={12}/>
                        </Button>
                        <span className="fw-bold px-1">{item.cantidad}</span>
                        <Button 
                          variant="light" 
                          size="sm" 
                          className="border"
                          onClick={() => ajustarCantidad(item.id, 1)}
                        >
                          <Plus size={12}/>
                        </Button>
                      </div>
                    </td>
                    <td className="fw-bold text-end px-4">
                      ${(item.precio * item.cantidad).toLocaleString('es-CL')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Col>

        {/* Resumen de Pago */}
        <Col lg={4}>
          <Card className="border-0 shadow-sm rounded-4 p-4 sticky-top" style={{ top: '110px' }}>
            <h5 className="fw-bold mb-4">Resumen de Orden</h5>
            <div className="d-flex justify-content-between mb-2 text-muted">
              <span>Productos ({carrito.length})</span>
              <span>${totalCarrito.toLocaleString('es-CL')}</span>
            </div>
            <div className="d-flex justify-content-between mb-3 text-muted">
              <span>Envío</span>
              <span className="text-success fw-bold">Gratis</span>
            </div>
            <hr />
            <div className="d-flex justify-content-between mb-4 fw-bold fs-4">
              <span>Total</span>
              <span style={{ color: '#ff85a2' }}>${totalCarrito.toLocaleString('es-CL')}</span>
            </div>
            <Button 
              variant="primary" 
              size="lg" 
              className="w-100 border-0 fw-bold py-3 shadow" 
              style={{ backgroundColor: '#ff85a2' }}
            >
              Ir a Pagar
            </Button>
            <p className="text-center text-muted mt-3 small">
              Aceptamos todo medio de pago
            </p>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default CarritoCompras;