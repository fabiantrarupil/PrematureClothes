import { useState, useContext } from 'react';
import { Container, Row, Col, Card, Form, Button } from 'react-bootstrap';
import { ProductContext } from '../context/ProductContext';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Lock, Baby } from 'lucide-react';

const Auth = ({ inicialEsLogin }) => {
  const [esLogin, setEsLogin] = useState(inicialEsLogin); // Switch entre login y registro
  const { setUser } = useContext(ProductContext);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulación de Auth para el proyecto
    setUser({ email: 'test@usuario.cl', nombre: 'Papá Guerrero' });
    navigate('/profile');
  };

  return (
    <Container className="my-5 pt-5">
      <Row className="justify-content-center">
        <Col md={6} lg={5}>
          <Card className="border-0 shadow-lg rounded-4 p-4">
            <div className="text-center mb-4">
              <h2 className="fw-bold">{esLogin ? '¡Hola de nuevo!' : 'Únete a nosotros'}</h2>
              <p className="text-muted small">
                {esLogin ? 'Ingresa para ver tus favoritos' : 'Crea una cuenta para tu familia'}
              </p>
            </div>

            <Form onSubmit={handleSubmit}>
              {!esLogin && (
                <Form.Group className="mb-3">
                  <Form.Label className="small fw-bold">Nombre Completo</Form.Label>
                  <Form.Control type="text" placeholder="Ej: Juan Castrp" required />
                </Form.Group>
              )}

              <Form.Group className="mb-3">
                <Form.Label className="small fw-bold">Email</Form.Label>
                <Form.Control type="email" placeholder="correo@ejemplo.com" required />
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="small fw-bold">Contraseña</Form.Label>
                <Form.Control type="password" placeholder="••••••••" required />
              </Form.Group>

              <Button 
                variant="primary" 
                type="submit" 
                className="w-100 py-3 fw-bold border-0 shadow"
                style={{ backgroundColor: '#ff85a2' }}
              >
                {esLogin ? 'Ingresar' : 'Registrarme'}
              </Button>
            </Form>

            <div className="text-center mt-4">
              <Button 
                variant="link" 
                className="text-decoration-none text-muted small"
                onClick={() => setEsLogin(!esLogin)}
              >
                {esLogin ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Ingresa aquí'}
              </Button>
            </div>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Auth;